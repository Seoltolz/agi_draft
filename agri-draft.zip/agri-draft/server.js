// Agricola Draft-only Mini Game — server (v0.2)
// Node.js + Express + Socket.IO
// Adds: image/ability card metadata, admin edit endpoints, bulk import,
//       end-of-draft voting, tier scoring, pick-frequency stats.

const path = require('path');
const fs = require('fs');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { nanoid } = require('nanoid');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DECKS_DIR = path.join(DATA_DIR, 'decks');
const HISTORY_DIR = path.join(DATA_DIR, 'history');
const STATS_FILE = path.join(DATA_DIR, 'stats.json');

// ---------- Deck loading ----------
function loadDecks() {
  const decks = {};
  const files = fs.readdirSync(DECKS_DIR).filter(f => f.endsWith('.json'));
  for (const f of files) {
    try {
      const d = JSON.parse(fs.readFileSync(path.join(DECKS_DIR, f), 'utf8'));
      // Normalize card shape
      for (const kind of ['occupations','minorImprovements']){
        d[kind] = (d[kind]||[]).map(c => ({
          code: String(c.code),
          name: String(c.name||''),
          ability: String(c.ability||''),
          imageUrl: String(c.imageUrl||''),
        }));
      }
      decks[d.id] = d;
    } catch (e) { console.error('deck load fail', f, e.message); }
  }
  return decks;
}
let DECKS = loadDecks();
function reloadDecks() { DECKS = loadDecks(); }
function saveDeck(deck){
  fs.writeFileSync(path.join(DECKS_DIR, `${deck.id}.json`), JSON.stringify(deck, null, 2));
  reloadDecks();
}

// ---------- Stats (card tier / freq) ----------
function loadStats(){
  try { return JSON.parse(fs.readFileSync(STATS_FILE,'utf8')); }
  catch { return { cards: {} }; } // cards: { code: { name, deckId, kind, picked, seen, votes, score } }
}
function saveStats(s){ fs.writeFileSync(STATS_FILE, JSON.stringify(s, null, 2)); }
let STATS = loadStats();

// ---------- Utils ----------
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------- Rooms ----------
const rooms = new Map();

function publicRoom(room) {
  return {
    id: room.id,
    hostId: room.hostId,
    deckIds: room.deckIds,
    decks: room.deckIds.map(id => DECKS[id] ? { id, name: DECKS[id].name } : { id, name: id }),
    cardsPerHand: room.cardsPerHand,
    players: room.players.map(p => ({ id: p.id, name: p.name, ready: !!p.ready, pickedCount: p.picked.length })),
    status: room.status,
    phase: room.phase,
    round: room.round,
    logCount: room.log.length,
  };
}

function playerView(room, playerId) {
  const me = room.players.find(p => p.id === playerId);
  return {
    room: publicRoom(room),
    me: me ? {
      id: me.id, name: me.name,
      hand: room.hands[me.id] || [],
      picked: me.picked,
      hasPickedThisRound: !!me.pickedThisRound,
      myVotes: room.votes ? (room.votes[me.id] || {}) : null,
    } : null,
    others: room.players.map(p => p.id === playerId ? null : ({
      id: p.id, name: p.name,
      handSize: (room.hands[p.id] || []).length,
      picked: p.picked,
      hasPickedThisRound: !!p.pickedThisRound,
    })).filter(Boolean),
    log: room.log,
    voting: room.voting || null,   // { open, results }
  };
}

function emitRoom(room) {
  for (const p of room.players) {
    if (p.socketId) io.to(p.socketId).emit('state', playerView(room, p.id));
  }
}

// ---------- Draft logic ----------
function buildPool(room, kind) {
  const all = [];
  for (const deckId of room.deckIds) {
    const d = DECKS[deckId]; if (!d) continue;
    for (const c of (d[kind] || [])) all.push({ ...c, deckId });
  }
  return shuffle(all);
}

function dealPhase(room, phase) {
  const kind = phase === 'occupations' ? 'occupations' : 'minorImprovements';
  const pool = buildPool(room, kind);
  const need = room.cardsPerHand * room.players.length;
  if (pool.length < need) {
    return { error: `${kind} 카드 부족: 필요 ${need}, 풀 ${pool.length}. 덱 선택을 늘리거나 한손 카드 수를 줄이세요.` };
  }
  room.hands = {};
  let idx = 0;
  for (const p of room.players) {
    room.hands[p.id] = pool.slice(idx, idx + room.cardsPerHand);
    idx += room.cardsPerHand;
    p.pickedThisRound = false;
  }
  // Record "seen" for stats
  for (const p of room.players) {
    for (const c of room.hands[p.id]) {
      const rec = STATS.cards[c.code] || { name:c.name, deckId:c.deckId, kind, picked:0, seen:0, votes:0, score:0 };
      rec.name = c.name; rec.deckId = c.deckId; rec.kind = kind;
      rec.seen = (rec.seen||0) + 1;
      STATS.cards[c.code] = rec;
    }
  }
  saveStats(STATS);
  room.phase = phase;
  room.round = 1;
  return { ok: true };
}

function allPickedThisRound(room) {
  return room.players.every(p => p.pickedThisRound);
}

function passHands(room) {
  const n = room.players.length;
  const dir = (room.round % 2 === 1) ? 1 : -1;
  const newHands = {};
  for (let i = 0; i < n; i++) {
    const from = room.players[i];
    const toIdx = ((i + dir) % n + n) % n;
    const to = room.players[toIdx];
    newHands[to.id] = room.hands[from.id];
  }
  room.hands = newHands;
  for (const p of room.players) p.pickedThisRound = false;
  room.round += 1;
}

function endPhaseOrDraft(room) {
  if (room.round > room.cardsPerHand) {
    if (room.phase === 'occupations') {
      const r = dealPhase(room, 'minors');
      if (r.error) { room.status='finished'; openVoting(room); finalizeHistory(room, r.error); return; }
      return;
    } else {
      room.status = 'finished';
      openVoting(room);
      finalizeHistory(room);
    }
  }
}

function openVoting(room){
  // Peer voting: each player rates every OTHER player's build 1..5 stars.
  // Also each player can up-vote / down-vote individual CARDS as MVP / DUD.
  room.voting = { open: true, closed: false };
  room.votes = {}; // { voterId: { playerScores:{targetId:1..5}, mvpCards:[code], dudCards:[code] } }
  for (const p of room.players) room.votes[p.id] = { playerScores:{}, mvpCards:[], dudCards:[] };
}

function tallyVotes(room){
  const totals = {};
  const counts = {};
  for (const voter of Object.values(room.votes||{})){
    for (const [target, score] of Object.entries(voter.playerScores||{})){
      totals[target] = (totals[target]||0) + Number(score);
      counts[target] = (counts[target]||0) + 1;
    }
  }
  const perPlayer = {};
  for (const p of room.players){
    perPlayer[p.id] = {
      total: totals[p.id]||0,
      count: counts[p.id]||0,
      avg: counts[p.id] ? +(totals[p.id]/counts[p.id]).toFixed(2) : 0,
    };
  }
  return perPlayer;
}

function applyVotesToStats(room){
  // Aggregate MVP/dud into STATS.cards
  const mvpTally = {}, dudTally = {};
  for (const voter of Object.values(room.votes||{})){
    for (const code of voter.mvpCards||[]) mvpTally[code] = (mvpTally[code]||0)+1;
    for (const code of voter.dudCards||[]) dudTally[code] = (dudTally[code]||0)-1;
  }
  const per = tallyVotes(room);
  // Map each picked card to its picker's avg rating (peer-rated build quality).
  // Card tier score is a weighted mix: base picks + (avg rating - 3) contributions + MVP/dud deltas.
  for (const p of room.players){
    const buildAvg = per[p.id]?.avg || 0;
    const rating = buildAvg > 0 ? (buildAvg - 3) : 0; // 3 = neutral
    for (const c of p.picked){
      const rec = STATS.cards[c.code];
      if (!rec) continue;
      rec.score = (rec.score||0) + rating * 0.5;
    }
  }
  for (const [code, v] of Object.entries(mvpTally)){
    const rec = STATS.cards[code]; if (rec) { rec.score = (rec.score||0) + v; rec.votes = (rec.votes||0) + v; }
  }
  for (const [code, v] of Object.entries(dudTally)){
    const rec = STATS.cards[code]; if (rec) { rec.score = (rec.score||0) + v; rec.votes = (rec.votes||0) + v; }
  }
  saveStats(STATS);
}

function finalizeHistory(room, note) {
  const rec = {
    id: room.id,
    finishedAt: new Date().toISOString(),
    deckIds: room.deckIds,
    deckNames: room.deckIds.map(id => DECKS[id]?.name || id),
    players: room.players.map(p => ({ id: p.id, name: p.name, picks: p.picked })),
    log: room.log,
    votes: room.votes || null,
    voteTally: room.voting ? tallyVotes(room) : null,
    note: note || null,
  };
  try {
    const file = path.join(HISTORY_DIR, `${room.id}-${Date.now()}.json`);
    room.historyFile = path.basename(file);
    fs.writeFileSync(file, JSON.stringify(rec, null, 2));
  } catch (e) { console.error('save history', e.message); }
}

function finalizeVoting(room){
  if (!room.voting || room.voting.closed) return;
  room.voting.closed = true;
  applyVotesToStats(room);
  // Update pick counts on stats
  for (const p of room.players){
    for (const c of p.picked){
      const rec = STATS.cards[c.code];
      if (rec) { rec.picked = (rec.picked||0) + 1; rec.name = c.name; rec.deckId = c.deckId; }
    }
  }
  saveStats(STATS);
  // Overwrite the history file with final tallies
  if (room.historyFile){
    try {
      const p = path.join(HISTORY_DIR, room.historyFile);
      const j = JSON.parse(fs.readFileSync(p,'utf8'));
      j.votes = room.votes;
      j.voteTally = tallyVotes(room);
      fs.writeFileSync(p, JSON.stringify(j, null, 2));
    } catch(e){ console.error('update history', e.message); }
  }
}

// ---------- HTTP ----------
app.use(express.json({limit:'5mb'}));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/decks', (req, res) => {
  reloadDecks();
  res.json(Object.values(DECKS).map(d => ({
    id: d.id, name: d.name, description: d.description || '',
    occupations: (d.occupations || []).length,
    minorImprovements: (d.minorImprovements || []).length,
  })));
});

app.get('/api/decks/:id', (req, res) => {
  reloadDecks();
  const d = DECKS[req.params.id];
  if (!d) return res.status(404).json({error:'not found'});
  res.json(d);
});

// Admin: bulk update deck cards (ability / imageUrl / name)
// Body: { cards: [{code, name?, ability?, imageUrl?}] }
app.post('/api/decks/:id/patch', (req, res) => {
  const d = DECKS[req.params.id];
  if (!d) return res.status(404).json({error:'deck not found'});
  const updates = req.body?.cards || [];
  const map = new Map(updates.map(u => [String(u.code), u]));
  let changed = 0;
  for (const kind of ['occupations','minorImprovements']){
    for (const c of d[kind]){
      const u = map.get(c.code);
      if (!u) continue;
      if (typeof u.name === 'string' && u.name.length) c.name = u.name;
      if (typeof u.ability === 'string') c.ability = u.ability;
      if (typeof u.imageUrl === 'string') c.imageUrl = u.imageUrl;
      changed++;
    }
  }
  saveDeck(d);
  res.json({ok:true, changed});
});

// Admin: import CSV (code,name,ability,imageUrl,kind,deckId)
// Body: { csv: "..." }  -- header row required, comma-separated with quotes.
function parseCSV(txt){
  const rows=[]; let i=0, cur='', row=[], q=false;
  while (i<txt.length){
    const ch=txt[i];
    if (q){
      if (ch=='"' && txt[i+1]=='"'){ cur+='"'; i+=2; continue; }
      if (ch=='"'){ q=false; i++; continue; }
      cur+=ch; i++; continue;
    }
    if (ch=='"'){ q=true; i++; continue; }
    if (ch==','){ row.push(cur); cur=''; i++; continue; }
    if (ch=='\n' || ch=='\r'){ if (cur.length||row.length){ row.push(cur); rows.push(row); } cur=''; row=[]; if (ch=='\r' && txt[i+1]=='\n') i++; i++; continue; }
    cur+=ch; i++;
  }
  if (cur.length||row.length){ row.push(cur); rows.push(row); }
  return rows;
}
app.post('/api/import/csv', (req, res) => {
  const csv = req.body?.csv || '';
  const rows = parseCSV(csv).filter(r => r.some(x=>x&&x.trim().length));
  if (rows.length < 2) return res.status(400).json({error:'CSV empty'});
  const head = rows[0].map(s=>s.trim().toLowerCase());
  const iCode = head.indexOf('code'), iName = head.indexOf('name'),
        iAbility = head.indexOf('ability'), iImg = head.indexOf('imageurl'),
        iDeck = head.indexOf('deckid'), iKind = head.indexOf('kind');
  if (iCode<0) return res.status(400).json({error:'CSV needs code column'});
  reloadDecks();
  // Build code -> {deckId,kind,card} index
  const idx = new Map();
  for (const d of Object.values(DECKS)){
    for (const kind of ['occupations','minorImprovements'])
      for (const c of d[kind]) idx.set(c.code, {deckId:d.id, kind, card:c});
  }
  let changed=0, added=0;
  for (let r=1;r<rows.length;r++){
    const row = rows[r];
    const code = (row[iCode]||'').trim(); if (!code) continue;
    const name = iName>=0 ? (row[iName]||'').trim() : '';
    const ability = iAbility>=0 ? (row[iAbility]||'') : '';
    const img = iImg>=0 ? (row[iImg]||'').trim() : '';
    const deckId = iDeck>=0 ? (row[iDeck]||'').trim() : '';
    const kind = iKind>=0 ? (row[iKind]||'').trim() : '';
    const hit = idx.get(code);
    if (hit){
      if (name) hit.card.name = name;
      if (typeof ability==='string') hit.card.ability = ability;
      if (typeof img==='string') hit.card.imageUrl = img;
      changed++;
    } else if (deckId && kind && name){
      const d = DECKS[deckId]; if (!d) continue;
      const list = kind==='occupations' ? d.occupations : d.minorImprovements;
      list.push({code, name, ability: ability||'', imageUrl: img||''});
      added++;
    }
  }
  for (const d of Object.values(DECKS)) saveDeck(d);
  res.json({ok:true, changed, added});
});

app.get('/api/history', (req, res) => {
  try {
    const files = fs.readdirSync(HISTORY_DIR).filter(f => f.endsWith('.json'));
    const items = files.map(f => {
      const j = JSON.parse(fs.readFileSync(path.join(HISTORY_DIR, f), 'utf8'));
      return { file:f, id:j.id, finishedAt:j.finishedAt, deckNames:j.deckNames, players:j.players.map(p=>p.name), voteTally:j.voteTally||null };
    }).sort((a,b)=>(b.finishedAt||'').localeCompare(a.finishedAt||''));
    res.json(items);
  } catch (e) { res.status(500).json({error:e.message}); }
});

app.get('/api/history/:file', (req, res) => {
  const f = req.params.file;
  if (!/^[a-zA-Z0-9_\-]+\.json$/.test(f)) return res.status(400).json({error:'bad name'});
  const p = path.join(HISTORY_DIR, f);
  if (!fs.existsSync(p)) return res.status(404).json({error:'not found'});
  res.sendFile(p);
});

app.get('/api/stats', (req, res) => {
  const arr = Object.entries(STATS.cards).map(([code, v]) => ({ code, ...v }));
  arr.sort((a,b)=> (b.score||0) - (a.score||0));
  res.json(arr);
});

// ---------- Socket ----------
io.on('connection', (socket) => {
  let currentRoomId = null;
  let currentPlayerId = null;

  socket.on('createRoom', ({ name, deckIds, cardsPerHand }, cb) => {
    try {
      if (!name || !name.trim()) return cb && cb({ error: '이름을 입력하세요.' });
      if (!Array.isArray(deckIds) || deckIds.length === 0) return cb && cb({ error: '덱을 1개 이상 선택하세요.' });
      for (const id of deckIds) if (!DECKS[id]) return cb && cb({ error: `알 수 없는 덱: ${id}` });
      const cph = Number(cardsPerHand) || 7;
      if (cph < 3 || cph > 10) return cb && cb({ error: '한손 카드 수는 3~10.' });
      const roomId = nanoid(6).toUpperCase();
      const playerId = nanoid(8);
      const room = {
        id: roomId, hostId: playerId, deckIds, cardsPerHand: cph,
        players: [{ id: playerId, name: name.trim(), socketId: socket.id, ready:false, picked:[], pickedThisRound:false }],
        status:'lobby', phase:null, round:0, hands:{}, log:[],
      };
      rooms.set(roomId, room);
      currentRoomId = roomId; currentPlayerId = playerId;
      socket.join(roomId);
      cb && cb({ ok:true, roomId, playerId });
      emitRoom(room);
    } catch (e) { cb && cb({ error: e.message }); }
  });

  socket.on('joinRoom', ({ roomId, name, playerId }, cb) => {
    try {
      const room = rooms.get((roomId || '').toUpperCase());
      if (!room) return cb && cb({ error: '방을 찾을 수 없음.' });
      if (playerId){
        const existing = room.players.find(p => p.id === playerId);
        if (existing){
          existing.socketId = socket.id;
          if (name && name.trim()) existing.name = name.trim();
          currentRoomId = room.id; currentPlayerId = existing.id;
          socket.join(room.id);
          cb && cb({ ok:true, roomId:room.id, playerId:existing.id, reconnected:true });
          emitRoom(room); return;
        }
      }
      if (room.status !== 'lobby') return cb && cb({ error: '이미 진행 중 - 새 참가 불가.' });
      if (room.players.length >= 4) return cb && cb({ error: '방 가득 참 (최대 4인).' });
      if (!name || !name.trim()) return cb && cb({ error: '이름을 입력하세요.' });
      const newId = nanoid(8);
      room.players.push({ id:newId, name:name.trim(), socketId:socket.id, ready:false, picked:[], pickedThisRound:false });
      currentRoomId = room.id; currentPlayerId = newId;
      socket.join(room.id);
      cb && cb({ ok:true, roomId:room.id, playerId:newId });
      emitRoom(room);
    } catch (e) { cb && cb({ error: e.message }); }
  });

  socket.on('leaveRoom', () => {
    if (!currentRoomId) return;
    const room = rooms.get(currentRoomId);
    if (!room) return;
    if (room.status === 'lobby') {
      room.players = room.players.filter(p => p.id !== currentPlayerId);
      if (room.players.length === 0) rooms.delete(room.id);
      else { if (room.hostId===currentPlayerId) room.hostId = room.players[0].id; emitRoom(room); }
    }
    socket.leave(currentRoomId);
    currentRoomId=null; currentPlayerId=null;
  });

  socket.on('startDraft', (_, cb) => {
    if (!currentRoomId) return cb && cb({ error: '방 없음.' });
    const room = rooms.get(currentRoomId);
    if (!room) return cb && cb({ error: '방 없음.' });
    if (room.hostId !== currentPlayerId) return cb && cb({ error: '호스트만 시작.' });
    if (room.players.length < 2) return cb && cb({ error: '최소 2인.' });
    if (room.players.length > 4) return cb && cb({ error: '최대 4인.' });
    room.players = shuffle(room.players);
    const r = dealPhase(room, 'occupations');
    if (r.error) return cb && cb({ error: r.error });
    room.status = 'drafting';
    emitRoom(room);
    cb && cb({ ok:true });
  });

  socket.on('pickCard', ({ cardCode }, cb) => {
    if (!currentRoomId) return cb && cb({ error:'방 없음.' });
    const room = rooms.get(currentRoomId);
    if (!room || room.status !== 'drafting') return cb && cb({ error:'드래프트 중 아님.' });
    const me = room.players.find(p => p.id === currentPlayerId);
    if (!me) return cb && cb({ error:'플레이어 없음.' });
    if (me.pickedThisRound) return cb && cb({ error:'이미 픽함.' });
    const hand = room.hands[me.id] || [];
    const idx = hand.findIndex(c => c.code === cardCode);
    if (idx < 0) return cb && cb({ error:'내 손에 없는 카드.' });
    const [card] = hand.splice(idx, 1);
    me.picked.push({ ...card, phase: room.phase, round: room.round });
    me.pickedThisRound = true;
    room.log.push({ phase:room.phase, round:room.round, playerId:me.id, playerName:me.name, card, ts:Date.now() });
    cb && cb({ ok:true });
    if (allPickedThisRound(room)){
      const anyLeft = room.players.some(p => (room.hands[p.id]||[]).length > 0);
      if (anyLeft) passHands(room);
      else { room.round += 1; endPhaseOrDraft(room); }
    }
    emitRoom(room);
  });

  socket.on('rename', ({ name }) => {
    if (!currentRoomId) return;
    const room = rooms.get(currentRoomId); if (!room) return;
    const me = room.players.find(p => p.id === currentPlayerId); if (!me) return;
    if (name && name.trim()) me.name = name.trim();
    emitRoom(room);
  });

  socket.on('vote', ({ playerScores, mvpCards, dudCards }, cb) => {
    if (!currentRoomId) return cb && cb({error:'방 없음.'});
    const room = rooms.get(currentRoomId); if (!room || !room.voting?.open) return cb && cb({error:'투표 중 아님.'});
    const me = room.players.find(p => p.id === currentPlayerId); if (!me) return cb && cb({error:'플레이어 없음.'});
    const v = room.votes[me.id] = { playerScores:{}, mvpCards:[], dudCards:[] };
    for (const [tid, sc] of Object.entries(playerScores||{})){
      if (tid === me.id) continue;
      const n = Math.round(Number(sc));
      if (n>=1 && n<=5 && room.players.find(p=>p.id===tid)) v.playerScores[tid] = n;
    }
    v.mvpCards = (mvpCards||[]).filter(c=>typeof c==='string').slice(0,10);
    v.dudCards = (dudCards||[]).filter(c=>typeof c==='string').slice(0,10);
    cb && cb({ok:true});
    // If all players submitted, close.
    const allDone = room.players.every(p => Object.keys(room.votes[p.id]?.playerScores||{}).length >= (room.players.length-1));
    if (allDone) finalizeVoting(room);
    emitRoom(room);
  });

  socket.on('closeVoting', (_, cb) => {
    if (!currentRoomId) return cb && cb({error:'방 없음.'});
    const room = rooms.get(currentRoomId); if (!room) return cb && cb({error:'방 없음.'});
    if (room.hostId !== currentPlayerId) return cb && cb({error:'호스트만 마감.'});
    finalizeVoting(room);
    cb && cb({ok:true});
    emitRoom(room);
  });

  socket.on('disconnect', () => {
    if (!currentRoomId) return;
    const room = rooms.get(currentRoomId); if (!room) return;
    const me = room.players.find(p => p.id === currentPlayerId);
    if (me) me.socketId = null;
    if (room.status === 'lobby' && room.players.every(p => !p.socketId)) {
      setTimeout(()=>{ const r=rooms.get(room.id); if (r && r.status==='lobby' && r.players.every(p=>!p.socketId)) rooms.delete(r.id); }, 5*60*1000);
    }
    emitRoom(room);
  });
});

server.listen(PORT, () => { console.log(`Agri-Draft server on :${PORT}`); });
